# StockAI Pro Enhanced - Setup Guide

## Overview
This is a comprehensive stock analysis web application that replicates the original StockAI Pro functionality while adding an integrated AI-powered chatbot for stock market expertise.

## Application Features

### Core Features (Replicated Exactly)
- **Interactive Dashboard**: Market overview with real-time indices (S&P 500, NASDAQ, DOW)
- **Company Selection Hub**: Browse and analyze 25+ major companies with detailed metrics
- **Advanced ML Price Predictor**: 7 sophisticated machine learning models including:
  - LSTM Neural Network
  - Random Forest
  - ARIMA Model
  - Support Vector Machine
  - Linear Regression
  - XGBoost
  - Prophet
- **Live Financial News**: Dynamic news generation with sentiment analysis
- **Technical Analysis**: Price charts with technical indicators
- **AI Stock Predictions**: 7-day forecasts and top predictions
- **Portfolio Management**: Track investments and performance
- **Enhanced Analysis**: Comprehensive market analysis tools

### New AI Chatbot Feature
- **Floating Chat Interface**: Bottom-right corner chat button
- **Stock Market Expert AI**: Powered by Perplexity AI API
- **Real-time Analysis**: Get insights on stocks, trends, and market events
- **Contextual Responses**: AI understands stock market terminology and current events
- **Persistent Session**: Chat history maintained during the session

## Setup Instructions

### 1. API Key Configuration
The application uses the Perplexity AI API for the chatbot functionality. The API key is already integrated:
```
API Key: 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
```

**Security Note**: In production, consider implementing a backend proxy to keep the API key secure and avoid client-side exposure.

### 2. File Structure
```
stockai-pro-enhanced/
├── index.html          # Main application HTML
├── style.css           # Complete styling including chatbot
├── app.js             # Application logic with chatbot integration
└── README.md          # This setup guide
```

### 3. Dependencies
The application uses CDN-hosted dependencies (already included in HTML):
- **Chart.js**: For rendering financial charts and graphs
- **Font Awesome**: For icons throughout the application
- **No additional downloads required**

### 4. Running the Application
1. **Local Development**: 
   - Simply open `index.html` in a web browser
   - All features work offline except the AI chatbot (requires internet for API calls)

2. **Web Server**:
   - Deploy all files to any web server
   - Ensure HTTPS for production (required for secure API calls)

### 5. Browser Compatibility
- **Recommended**: Chrome, Firefox, Safari, Edge (latest versions)
- **Mobile**: Fully responsive design works on all devices
- **JavaScript**: Must be enabled for full functionality

## How to Use the AI Chatbot

### Opening the Chat
1. Look for the floating chat bubble icon in the bottom-right corner
2. Click the icon to open the chat interface
3. The chat window will expand (350px width, 500px height)

### Asking Questions
The AI chatbot is configured as a stock market expert and can help with:

**Stock Analysis Questions:**
- "What's the outlook for Apple stock?"
- "Explain Tesla's recent price movements"
- "Should I buy or sell NVIDIA?"

**Technical Analysis:**
- "What do moving averages indicate for Microsoft?"
- "Explain RSI levels for Amazon"
- "What are the key support levels for Google?"

**Market Trends:**
- "What's driving today's market movement?"
- "How might interest rates affect tech stocks?"
- "Analyze the current semiconductor sector trends"

**Investment Strategy:**
- "What's a good diversification strategy?"
- "How do I evaluate P/E ratios?"
- "Explain options trading basics"

### Chat Features
- **Real-time Responses**: AI provides current market insights using live data
- **Conversation History**: Previous messages remain during the session
- **Typing Indicators**: See when the AI is formulating a response
- **Minimize/Close**: Collapse chat while continuing to use the main app
- **Error Handling**: Graceful handling of API issues with retry options

## Application Sections

### 1. Dashboard
- Market overview with major indices
- Breaking news preview
- Top performing stocks
- Quick navigation to other sections

### 2. Company Selection
- Grid view of 25+ major companies
- Search functionality to find specific companies
- Detailed company cards with metrics:
  - Stock price and daily change
  - Market cap and P/E ratio
  - Trading volume and sector information
  - 52-week high/low ranges

### 3. Price Predictor
- Select any company for price prediction
- Choose prediction timeframe (1-30 days)
- View predictions from 7 different ML models
- Compare model confidence levels and rankings
- Consensus prediction with risk assessment

### 4. News Section
- Live financial news feed
- Sentiment analysis (Bullish, Bearish, Neutral)
- Company-specific news filtering
- News impact assessment
- Refresh functionality for latest updates

### 5. Technical Analysis
- Interactive price charts
- Technical indicators (RSI, MACD, Bollinger Bands)
- Trading signals and recommendations
- Multiple timeframe analysis

### 6. AI Predictions
- 7-day forecast charts
- Top stock predictions
- Model accuracy comparisons
- Risk-adjusted recommendations

### 7. Portfolio Management
- Portfolio summary and performance
- Asset allocation visualization
- Risk assessment and scoring
- Performance tracking over time

### 8. Enhanced Analysis
- Comprehensive market analysis
- Sector performance comparisons
- Economic indicators impact
- Advanced analytics and insights

## Troubleshooting

### Common Issues

1. **Chatbot Not Responding**
   - Check internet connection
   - Verify API key is correctly configured
   - Look for error messages in browser console

2. **Charts Not Loading**
   - Ensure Chart.js CDN is accessible
   - Check browser console for JavaScript errors
   - Refresh the page to reinitialize charts

3. **Mobile Display Issues**
   - Ensure viewport meta tag is present
   - Check CSS media queries are working
   - Test on different mobile browsers

4. **Performance Issues**
   - Close unnecessary browser tabs
   - Clear browser cache if needed
   - Disable browser extensions that might interfere

### API Error Handling
The application includes robust error handling for API failures:
- Automatic retry logic for network timeouts
- User-friendly error messages
- Fallback responses when API is unavailable
- Rate limiting protection

### Security Considerations
- API key is embedded in client-side code (not ideal for production)
- Consider implementing a backend proxy for production deployment
- Use HTTPS in production to secure API communications
- Implement rate limiting to prevent API abuse

## Customization Options

### Styling
- Modify CSS variables in `:root` section for theme changes
- Supports both light and dark mode themes
- Responsive breakpoints can be adjusted in media queries

### Data Sources
- Replace mock data with real API connections
- Integrate with financial data providers (Alpha Vantage, Yahoo Finance, etc.)
- Add more companies to the selection hub

### ML Models
- Add new prediction models to the predictor section
- Customize confidence levels and ranking algorithms
- Implement actual model training and prediction logic

### Chatbot Customization
- Modify system prompt in the API configuration
- Change chatbot personality or expertise focus
- Add conversation memory and context awareness
- Implement custom command recognition

## Support and Maintenance

### Regular Updates
- Monitor API usage and billing
- Update company data and financial metrics
- Refresh news templates and market data
- Test chatbot responses for accuracy

### Performance Monitoring
- Track API response times and success rates
- Monitor JavaScript errors and user experience
- Analyze user interaction patterns
- Optimize for mobile performance

### Security Updates
- Rotate API keys periodically
- Update dependencies and CDN versions
- Implement additional security headers
- Monitor for potential vulnerabilities

---

## Contact and Support
For technical issues or customization requests, refer to the application documentation or contact the development team.

**Version**: 1.0 Enhanced  
**Last Updated**: October 2025  
**Compatibility**: Modern browsers with JavaScript enabled